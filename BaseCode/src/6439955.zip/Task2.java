import java.util.Arrays;

public class Task2{

    public static int[] fillArray(int[] Array){
        int positiveIndex = countNegatives(Array, 0);
        int negativeIndex = 0;
        int[] temp = new int[Array.length];
        fillNegativesFirst(Array, positiveIndex, negativeIndex, 0, temp);

        return temp;
    }
    private static int countNegatives(int []array, int i){
        if(i == array.length){return 0;}
        return (array[i] < 0 ? 1 : 0) + countNegatives(array, i+1);
    }

    private static void fillNegativesFirst(int[] array, int posIndex, int negIndex, int i, int[] temp){
        if(i == array.length){return;}
        if(array[i]<0){
            temp[negIndex] = array[i];
            negIndex++;
            i++;
        } else {
            temp[posIndex] = array[i];
            posIndex++;
            i++;
        }
        fillNegativesFirst(array, posIndex, negIndex, i, temp);
    }

    public static void main(String[] args) {
        int[] arr = {1, -1, 3, 2, -7, -5, 11, 6};
        arr = fillArray(arr);
        System.out.println(Arrays.toString(arr));
    }

}


